import random
__author__ = '9485974'
UI = input("How many sides would you like on your dice?")
UIDos = input("How many dice would you like?")
Counter = 0
def Dicerino(inputerino):
    dice = []
    if(UI.isdigit()):
        for i in range(0,int(inputerino)):
            dice.insert(i, random.randrange(1,int(inputerino)))
        print(dice[random.randrange(1,int(inputerino))])
    else:
        print("Nice try guy, those aren't numbers")
while(Counter < int(UIDos)):
    Dicerino(UI)
    Counter += 1