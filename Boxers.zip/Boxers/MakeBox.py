from Box import box
userDefHeight = input("What is the height of your box?")
userDefLength = input("What is the length of your box?")
userDefWidth = input("What is the width of your box?")
aBox = box(int(userDefHeight), int(userDefLength), int(userDefWidth))
sAOrV = input("Would you like to find the Surface Area or Volume of your box?")
centiOrMeters = input("Centimeters or meters?")
if sAOrV == "Surface Area":
    if centiOrMeters == "Centimeters" or "centimeters":
        saC = aBox.calcSurfaceArea()
        print("The surface area of your box in centimeters is: ", float(saC), "cm")
    elif centiOrMeters == "meters" or "Meters":
        saM = aBox.calcSurfaceArea()
        print("The surface area of your box in meters is: ", float(saM), "m")
if sAOrV == "Volume":
    if centiOrMeters == "Centimeters" or "centimeters":
        vCm = aBox.calcVolume()
        print("The volume of your box in centimeters is: ", vCm, "cm")
    elif centiOrMeters == "meters" or "Meters":
        vM = aBox.calcVolume()
        print("The volume of your box in meters is: ", float(vM), "m")
        

