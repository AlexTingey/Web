class box:
    def __init__(self, length, width, height):
        self.length = length
        self.width = width
        self.height = height
    def calcSurfaceArea(self):
        return round(self.length*self.width*2 + self.length*self.height*2 + self.height*self.width*2, 2)
    def calcVolume(self):
        return self.length*self.width*self.height


